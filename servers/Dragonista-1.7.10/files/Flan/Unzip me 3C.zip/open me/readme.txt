Monolith Pack version 3 ausf. C for flans mod 4.8.0/4.9.0
which in turn, is for mine craft 1.7.10

Installation:
Install the latest version of minecraft forge that is available for minecraft 1.7.10.
Download flans mod 4.9.0 from www.flansmod.com, then shove flans mod into the mods folder within your .minecraft folder
Load minecraft and if these steps were done properly, a new folder named flan, or flans should magically appear within .minecraft
Shove the monolith pack (which should be in the same folder as this readme) into the flan folder.
In theory, it should work now. There will be some problems unless you also have dependency packs.
To make monolith pack work to its fullest, you will at least need jamio flan's simple parts, jamio flan's ww2 pack, Jamio Flan Modern Pack, and manus' smp parts pack. You will also need prototype’s future craft for the plasma model, but monolith pack can function without it.

Credits:
Chemical weapons by jamez28, togII model by war_monger, banana mech, type-74, f-15, m3 lee, and adfx morgan models by gunnisberg, banana mech coding by prototype, plasma model stolen from prototype, 
L85A2 model and coding by prototype, BMPT-72 model by prototype, I think some more crap may have been by prototype, large bomb model stolen from manus,
 2d icon for type 38 mk 2 and most missiles doodled by mylesVIN, T-80 alternate texture by clone guy, sounds stolen from various sources, hidden pictures within the files
stolen from various sources, schwerer Gustav model by 손병진(Sonbyeongjin) and just about everything else by LabJac.

Legal stuff:
Do not dare redistribute this without permission, (unless you are sharing official download link), you may steal and edit stats from the config files, but you may not 
touch any of the models without permission and if you do reverse-engineer configs, give me credit. Do not steal this pack, pretend it's yours, and sell it. 
If you feature it in youtube videos, give me credit and post a link to the pack in the video description. If you want to use this pack as part of a mod pack thing,
ask me for permission. Otherwise, go hence to Hell.