Package Readme
-------------------------------------------------------------------------------
Name:				Akaku Vehicle Package

Version-No.:			3.0
-------------------------------------------------------------------------------
Author:				Akaku

Contact:			http://akakumasterofflight.deviantart.com/
-------------------------------------------------------------------------------
Mc-Version:			1.7.10

Flans Mod Version:		4.5.1

Depencies:			Minecraft-SMP Parts Package 1.7.10b

Build with Forge Version:	1.7.10-10.13.0.1180
-------------------------------------------------------------------------------
This Package is free to download at http://minecraft-smp.de/e107_plugins/forum/forum_viewtopic.php?16276.0. 

If you downloaded it somewhere else or payed for it (single or as part of a
compilation) please report this to http://minecraft-smp.de/user.php?id.1944.